insert into customer(Id,email,first_name,last_name) values (1000, 'Sekhar1@cts.com', 'Soma1', 'sekhar1');
insert into customer(Id,email,first_name,last_name) values (1001, 'Sekhar2@cts.com', 'Soma2', 'sekhar2');
insert into customer(Id,email,first_name,last_name) values (1002, 'Sekhar3@cts.com', 'Soma3', 'sekhar3');