package com.onlineshopping.microservices.salesorderservice;

import java.util.Date;
import java.util.List;



public class InputData {
	
	private String orderDescription;
	private Date orderDate;
	private Long customerId;
	private List<OrderLineItems> listOfItemNames;
	
	public InputData(String orderDescription, Date orderDate, Long customerId, List<OrderLineItems> listOfItemNames) {
		super();
		this.orderDescription = orderDescription;
		this.orderDate = orderDate;
		this.customerId = customerId;
		this.listOfItemNames = listOfItemNames;
	}
	
	
	public InputData() {}


	public String getOrderDescription() {
		return orderDescription;
	}


	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}


	public Date getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}


	public Long getCustomerId() {
		return customerId;
	}


	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}


	public List<OrderLineItems> getListOfItemNames() {
		return listOfItemNames;
	}


	public void setListOfItemNames(List<OrderLineItems> listOfItemNames) {
		this.listOfItemNames = listOfItemNames;
	}
	
	
}
