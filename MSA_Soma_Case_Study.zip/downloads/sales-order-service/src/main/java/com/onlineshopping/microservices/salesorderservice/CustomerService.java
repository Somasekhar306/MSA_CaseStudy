package com.onlineshopping.microservices.salesorderservice;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;

//@FeignClient(name="customer-service", url="localhost:6080")
//@FeignClient(name="customer-service")
//@FeignClient(name="zuul-edge-server")
@RibbonClient(name="customer-service")
public interface CustomerService {

}
