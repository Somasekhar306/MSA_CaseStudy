package com.onlineshopping.microservices.salesorderservice;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SalesOrderController {
	
	private static Logger logger = LoggerFactory.getLogger(SalesOrderController.class);
	@Autowired
	OrderLineItemsRepository orderLineItemsRepository;
	
	@Autowired
	CustomerSOSRepository customerSOSRepository;
		
	@Autowired
	SalesOrderRepository salesOrderRepository;
	
	@Autowired
	ItemService itemService;
	
	@Autowired
	SalesOrder salesOrder;
	
//	@Autowired
//	OrderLineItems orderLineItems;
	
	Long lineId =0000000001L;
	Long orderId =0000000001L;
	Long salesOrderId =0000000001L; 
	
	@PostMapping("/service3/orders")
	public Long createOrder(@RequestBody InputData inputOrder){
		
		logger.info(" Inside createOrder  Method");
		//SalesOrder salesOrder = new SalesOrder(100L, "da",1000L, "order description",200);
		
		//Validate the customer from the customer_SOS table
		customerSOSRepository.findById(inputOrder.getCustomerId());
		
		ArrayList<String> lineItemNames = new ArrayList<String>();
		inputOrder.getListOfItemNames().stream().forEach(itemsNames -> {
			lineItemNames.add(itemsNames.getItemName());
		} );
		for(String name:lineItemNames) {
			itemService.getItemDetails(name);
		}
		//Insert Sales Order details into Sales Order Table
		salesOrderId = salesOrderId+1;
		
		
		salesOrder.setSoId(salesOrderId);
		salesOrder.setCustId(inputOrder.getCustomerId());
		salesOrder.setOrderDate(inputOrder.getOrderDate());
		salesOrder.setOrderDesc(inputOrder.getOrderDescription());
		salesOrder.setTotalPrice(45.9F);
		
		salesOrderRepository.save(salesOrder);
		
		//inserting the Line Item details into the OrderLineItem table
		orderId=orderId+1;
		inputOrder.getListOfItemNames().forEach(item -> {
			orderLineItemsRepository.save(new OrderLineItems(lineId++,item.getItemName(),item.getItemQuantity(),item.getOrderId()));
		});
		return orderId;
		
		}
	}
	
	
	


