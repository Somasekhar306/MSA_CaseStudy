package com.onlineshopping.microservices.salesorderservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderLineItems {
	
	@Id
	@Column(name="line_Id")
	private Long lineId;
	
	@Column(name="item_name")
	private String itemName;
	
	@Column(name="item_Quantity")
	private Integer itemQuantity;
	
	@Column(name="order_Id")
	private Long orderId;
	
	public OrderLineItems(Long lineId, String itemName, Integer itemQuantity, Long orderId) {
		super();
		this.lineId = lineId;
		this.itemName = itemName;
		this.itemQuantity = itemQuantity;
		this.orderId = orderId;
	}
	
	public OrderLineItems() {}

	public Long getLineId() {
		return lineId;
	}

	public void setLineId(Long lineId) {
		this.lineId = lineId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Integer getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	
	

}
