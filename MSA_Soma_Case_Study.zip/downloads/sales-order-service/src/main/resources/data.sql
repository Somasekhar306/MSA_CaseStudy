insert into Customer_SOS(cust_Id,cust_first_name,cust_last_name,cust_email) values (4001,'Soma1','sekhar1','Soma1@cts.com')
insert into Customer_SOS(cust_Id,cust_first_name,cust_last_name,cust_email) values (4002,'Soma2','sekhar2','Soma2@cts.com')
insert into Customer_SOS(cust_Id,cust_first_name,cust_last_name,cust_email) values (4003,'Soma3','sekhar3','Soma3@cts.com')

