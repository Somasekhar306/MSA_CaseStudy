package com.online.shopping.microservices.itemservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Item {	
	
	@Id
	@Column(name="item_Id")
	private Long itemId;
	
	@Column(name="itemname")
	private String itemName;
	
	@Column(name="description")
	private String description;
	
	@Column(name="price")
	private double price;
	
	public Item(Long itemId, String itemName, String description, double price) {
		super();
		this.itemId = itemId;		
		this.itemName = itemName;
		this.description = description;
		this.price = price;
	}
	public Item() {}

	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
}
