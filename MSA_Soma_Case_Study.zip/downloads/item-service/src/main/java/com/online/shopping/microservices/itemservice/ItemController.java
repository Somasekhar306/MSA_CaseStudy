package com.online.shopping.microservices.itemservice;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@RestController
@EnableHystrix
public class ItemController {
	
	private static Logger logger = LoggerFactory.getLogger(ItemController.class);
	
	@Autowired
	ItemRepository itemRepository;
	
	@Autowired
	ItemConfiguration itemConfiguration;
	
	@GetMapping("/service2/items")
	public List<Item> getAllItems() {
	
		//return new Customer(2001L,"Sekhar@cts.com","Soma",20);
		logger.info(" Inside getAllItems Method");
		List<Item> item = itemRepository.findAll();
		return item;
	
	}
	
	@GetMapping("/service2/items/{itemName}")
	@HystrixCommand(fallbackMethod="fallBackItemDetails")
	public Item getItemDetails(@PathVariable String itemName) {
		
		logger.info(" Inside getItemDetails Method");
		//return new ItemName (2001L,"Book", "Ruled Book description", 10);
				
		Item item = itemRepository.findByItemName(itemName);
		if (item != null)			
		return item;
		else
		throw new RuntimeException("Item not found");
	}
	public Item fallBackItemDetails(String item) {
		return new Item(00L,itemConfiguration.getDefaultItemName(),itemConfiguration.getDefaultItemDesc(),0.00F);
	}
}
