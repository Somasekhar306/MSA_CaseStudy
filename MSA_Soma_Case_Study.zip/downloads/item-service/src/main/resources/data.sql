insert into item(item_Id,itemName,description,price) values (3001, 'Book', 'Ruled Book Des1', 10);
insert into item(item_Id,itemName,description,price) values (3002, 'Cap', 'Red Cap des2', 20.50);
insert into item(item_Id,itemName,description,price) values (3003, 'Laptop', 'Dell Laptop des3', 20000);
